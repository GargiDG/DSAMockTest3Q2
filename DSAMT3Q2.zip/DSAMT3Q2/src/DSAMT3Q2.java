class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class Queue {
    private Node front;
    private Node rear;

    public Queue() {
        front = null;
        rear = null;
    }

    public void enqueue(int data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }

        int dequeuedData = front.data;
        front = front.next;

        if (front == null) {
            rear = null;
        }

        return dequeuedData;
    }

    public boolean isEmpty() {
        return front == null;
    }
}


public class DSAMT3Q2 {
    public static void main(String[] args) {
        Queue queue = new Queue();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);

        System.out.println(queue.dequeue()); // Output: 10
        System.out.println(queue.dequeue()); // Output: 20

        System.out.println(queue.isEmpty()); // Output: false

        System.out.println(queue.dequeue()); // Output: 30

        System.out.println(queue.isEmpty()); // Output: true

        // Trying to dequeue from an empty queue will throw an exception
        // queue.dequeue();
    }
}
